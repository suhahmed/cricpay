# Paste this into the WSGI configuration file on PythonAnywhere (Web tab -> WSGI configuration file).
# Replace YOURUSERNAME.
import os, sys
path = "/home/YOURUSERNAME/cricket-tracker"
if path not in sys.path:
    sys.path.insert(0, path)
# Set the edit PIN from the website sidebar after it starts ("Set edit PIN").
from app import app as application, _load
_load(force=True)
