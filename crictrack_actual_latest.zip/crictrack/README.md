# CricTrack: cricket tournament payment tracker (Excel-backed)

A web UI for `data/2025_Cricket_Tournaments.xlsx`. **There is no database: the Excel file is the database.**

## Pages
- **Tournaments**: one card per tournament, each with collected/outstanding totals.
  - **+ New tournament** creates a new sheet in the workbook. You set the short name (sheet tab), tournament name, ground, fee, squad size, number of matches (1–15), cost per player per match (each match can differ) and optional opponent names. All the formulas are set up for you, with room for 30 players and an organiser summary.
  - **+ Add players** fills the next empty player rows on any tournament sheet and copies the row formulas. Anything typed in *Already paid* is logged as an opening payment.
  - **Edit matches** (new-style sheets) renames matches and changes the per-player cost. Everyone who played is re-charged automatically.
- **Advances**: each tournament can have an advance per player (default ₹3,000) and an expected total cost per player (default ₹3,500–4,000).
  - Set them when creating a tournament, or later with **Settings** on its card. They're saved as `Advance:` and `Expected cost:` lines in the tournament box on the sheet.
  - The overview shows an **Advance** column: ✓ when paid, or **Collect ₹X**, which opens Record payment with the shortfall filled in.
  - There's also an *Advances collected* card and an **Advance pending** status filter.
  - Every payment is tagged **Advance / Match fees / Other** in the new *Type* column of the Payments sheet.
- **Payment overview** (`/`): every player in every tournament, with amount due, paid so far, outstanding and status.
  - The six match boxes are clickable. ✓ means played. Clicking switches Yes/No and the amounts recalculate from the sheet's own formulas.
    - On sheets where Yes/No is typed in (GurukulMarvel, UCC, UrbanFarms), the click writes Yes/No into that cell.
    - On BRC-Rebelstars, Yes/No is calculated from the match line-up blocks, so the click adds the player to (or removes them from) that match's line-up.
  - **+ Record payment** or **+ Payment** on a row: amount, date, mode (UPI/Cash/Bank) and a note.
    - The amount is added to the player's *Paid* cell on their tournament sheet (or the last instalment cell feeding it, e.g. *Clearance* on GurukulMarvel).
    - It's also logged as a row on a **Payments** sheet that the app creates in the workbook.
  - **Export CSV** exports the filtered table.
- **Payment history**: all payments recorded from the website. **Undo** subtracts the amount again and deletes the log row.
- **Sheet view** (`/sheets`): edit any non-formula cell of the workbook directly (names, costs, instalments, dates…).

- Each change in the browser (Y/N attendance, amounts, Paid status, names, dates) is written **straight into the matching cell** of the Excel file.
- Formula cells (balances, totals, "To be paid", etc.) are **never overwritten**. The app calculates them with the workbook's own formulas, so the UI shows the same numbers Excel does. In the UI they are marked as calculated cells (hover to see the formula).
- If you edit the Excel file in Excel and save it, the web page picks up the change within about 15 seconds.
- Every 10 minutes of editing, a backup copy goes to `data/backups/` (the last 40 are kept).
- The **Excel** button downloads the current file.
- **Edit PIN:** click **🔑 Set edit PIN** at the bottom of the sidebar.
  - Once it's set, anyone with the link can view, but recording payments, marking matches, adding players and changing settings need the PIN.
  - **🔓 Editing on · Lock** locks editing again. **Change or remove PIN** appears while you're unlocked.
  - The PIN is stored hashed in `data/crictrack-settings.json`, not in the Excel file.
  - After 5 wrong tries, that device has to wait 60 seconds.

## Run it on your laptop

1. Install Python 3.10+ from python.org (on Windows, tick "Add Python to PATH").
2. After it starts, open the site and click **🔑 Set edit PIN** in the sidebar.
3. Double-click `start-windows.bat`, then open http://localhost:8000.

> Windows note: if the Excel file is open in Excel, Windows locks it and saves from the web will fail with a clear message. Close it in Excel and the next save goes through.

**Adding a new tournament:** copy an existing sheet in Excel, keep the same layout (`SN | Player | Match 1…` table, `SN | Player | Cost | Status` match blocks, `Sno | Name` instalments, a `Tournament:` info box), save, and it appears as a new tab.

---

## Making it public: pick one

### Option A: Keep the Excel file on your laptop and share a public link (5 minutes)
Best if you're fine with the laptop staying on while people use it.

1. Install Cloudflare's free `cloudflared` tool: https://developers.cloudflare.com/cloudflare-one/networks/connectors/cloudflare-tunnel/downloads/
   (Windows: `winget install --id Cloudflare.cloudflared`)
2. Start the tracker (above), then in a second terminal run:
   ```
   cloudflared tunnel --url http://localhost:8000
   ```
3. It prints a link like `https://random-words.trycloudflare.com`. Share it on the team WhatsApp. No account is needed.
   - The link changes each time you restart it. For a permanent URL, create a free Cloudflare account, add a domain and set up a *named tunnel*. (ngrok's free plan, which includes one static domain, is another option: `ngrok http 8000`.)

### Option B: Host it 24×7 for free on PythonAnywhere (laptop can be off)
The Excel file then lives on PythonAnywhere's disk (persistent storage, unlike Render/Vercel/Heroku-style free hosts, which wipe files on restart).

1. Sign up for a free account at https://www.pythonanywhere.com. Your site will be `https://YOURUSERNAME.pythonanywhere.com`.
2. **Files** tab → upload this folder as `/home/YOURUSERNAME/cricket-tracker/` (or upload the zip and run `unzip` in a Bash console).
3. **Consoles** → Bash:
   ```
   cd ~/cricket-tracker && pip3.11 install --user -r requirements.txt
   ```
4. **Web** tab → *Add a new web app* → *Manual configuration* → Python 3.11.
5. Open the *WSGI configuration file* link and replace its contents with `pythonanywhere_wsgi.py` (put in your username), then set the PIN from the site's sidebar. Click **Reload**.
6. Free-tier caveat: once a month, log in and click **"Run until 1 month from today"** on the Web tab, or the site goes to sleep. Use the site's **Excel** button whenever you want a copy of the file locally.

### Option C: Your own server or VPS
`pip install -r requirements.txt` then `PORT=8000 python app.py` (it uses the waitress production server), with nginx/Caddy for HTTPS in front.

## Settings (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `EDIT_PIN` | *(empty)* | Optional. Forces a fixed PIN and disables changing it from the site. Normally leave it unset and use **Set edit PIN**. |
| `TRACKER_XLSX` | `data/2025_Cricket_Tournaments.xlsx` | Which Excel file to use |
| `PORT` | `8000` | Port to listen on |
